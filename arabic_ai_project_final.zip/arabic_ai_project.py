from pyspark.sql import SparkSession
from pyspark.sql.functions import col, regexp_replace, trim
from pyspark.ml.feature import VectorAssembler
from pyspark.ml.classification import LogisticRegression
from pyspark.ml.evaluation import MulticlassClassificationEvaluator

# Start Spark
spark = SparkSession.builder \
    .appName("Arabic AI Text Detection Project") \
    .getOrCreate()

print("=== Spark Session Started ===")

# Read dataset from HDFS
df = spark.read.csv(
    "hdfs://localhost:9000/user/abdulaziz99/arabic_ai_project/raw/arabic_ai_balanced_dataset.csv",
    header=True,
    inferSchema=True
)

print("=== Dataset Loaded From HDFS ===")
print("Total Rows:", df.count())

print("=== Original Schema ===")
df.printSchema()

# Arabic text preprocessing
df = df.withColumn("clean_text", regexp_replace(col("clean_text"), "[ًٌٍَُِّْـ]", "")) \
       .withColumn("clean_text", regexp_replace(col("clean_text"), "[إأآا]", "ا")) \
       .withColumn("clean_text", regexp_replace(col("clean_text"), "ى", "ي")) \
       .withColumn("clean_text", regexp_replace(col("clean_text"), "ؤ", "و")) \
       .withColumn("clean_text", regexp_replace(col("clean_text"), "ئ", "ي")) \
       .withColumn("clean_text", regexp_replace(col("clean_text"), "[^\\u0600-\\u06FF\\s]", " ")) \
       .withColumn("clean_text", regexp_replace(col("clean_text"), "\\s+", " ")) \
       .withColumn("clean_text", trim(col("clean_text")))

print("=== Arabic Text Preprocessing Completed ===")

# Convert columns to correct data types
df = df.withColumn("word_count", col("word_count").cast("int")) \
       .withColumn("avg_word_length", col("avg_word_length").cast("double")) \
       .withColumn("label", col("label").cast("int"))

print("=== Converted Data Types ===")
df.printSchema()

# Remove null values
clean_df = df.dropna(subset=["label", "word_count", "avg_word_length", "clean_text"])

print("=== Cleaned Dataset Count ===")
print("Clean Rows:", clean_df.count())

print("=== Label Distribution ===")
clean_df.groupBy("label").count().show()

# Save processed data as Parquet in HDFS
clean_df.write.mode("overwrite").parquet(
    "hdfs://localhost:9000/user/abdulaziz99/arabic_ai_project/processed/parquet"
)

print("=== Processed Data Saved as Parquet in HDFS ===")

# Feature engineering using two stylometric features
assembler = VectorAssembler(
    inputCols=["word_count", "avg_word_length"],
    outputCol="features"
)

final_df = assembler.transform(clean_df)

print("=== Feature Vector Sample ===")
final_df.select("features", "label").show(5, truncate=False)

# Train / test split
train_data, test_data = final_df.randomSplit([0.8, 0.2], seed=42)

print("=== Train/Test Split ===")
print("Train:", train_data.count())
print("Test:", test_data.count())

# Logistic Regression model
lr = LogisticRegression(
    featuresCol="features",
    labelCol="label"
)

model = lr.fit(train_data)

print("=== Logistic Regression Model Trained ===")

# Prediction
predictions = model.transform(test_data)

print("=== Prediction Sample ===")
predictions.select("label", "prediction", "probability").show(10, truncate=False)

# Accuracy
accuracy_evaluator = MulticlassClassificationEvaluator(
    labelCol="label",
    predictionCol="prediction",
    metricName="accuracy"
)

accuracy = accuracy_evaluator.evaluate(predictions)

# F1 Score
f1_evaluator = MulticlassClassificationEvaluator(
    labelCol="label",
    predictionCol="prediction",
    metricName="f1"
)

f1_score = f1_evaluator.evaluate(predictions)

print("=== Final Results ===")
print("Accuracy =", accuracy)
print("F1 Score =", f1_score)

print("=== Confusion Matrix ===")
predictions.groupBy("label", "prediction").count().show()

spark.stop()
print("=== Spark Session Stopped ===")
